# (c) @AbirHasan2005

class Config:
    TG_API_ID = 28123504
    TG_API_HASH = "266272106c7fb627c1753f776e15e498"
    TG_BOT_TOKEN = "5939918113:AAHa9j6QkLbuM1ZnUavsJ0v7GINroRBzsZE"
    ADMIN_IDS = ["Nmfajis"]
    DUMP_CHANNEL_ID = -1001940823180
    MONGO_DB_ACCESS_URI = "mongodb+srv://usr:123@cluster0.ftt6apw.mongodb.net/?retryWrites=true&w=majority"
    MONGO_DB_COLLECTION_NAME = "DB-01"
    SMM_PANEL_API_KEY = "87752e15bbb34b11b8cdb8fde2f7acde"

    class Defaults:
        SLEEP_TIME = 60 * 15  # minutes
        QUANTITY = 5000
